
Install and activate -> ( .../elementor-pro/ )

Import manual template you want. -> (.../elementorism-landing-pages/)

